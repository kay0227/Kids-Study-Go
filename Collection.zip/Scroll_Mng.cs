﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scroll_Mng : MonoBehaviour
{
    /* Button Object */

    public int m_Num;     // 메뉴 갯수 입력
    public int cnt = 1;   // 메뉴 현재 위치
}
