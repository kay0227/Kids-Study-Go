﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Tale_fst : MonoBehaviour {

    public void ChangeTaleScene()
    {
        SceneManager.LoadScene("TaleScene");
    }
}