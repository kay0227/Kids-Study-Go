﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class TaleScene5 : MonoBehaviour
{

    public void ChangeTaleScene()
    {
        SceneManager.LoadScene("TaleScene5");
    }
}
