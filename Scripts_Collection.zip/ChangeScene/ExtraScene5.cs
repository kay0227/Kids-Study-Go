﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ExtraScene5 : MonoBehaviour
{

    public void ChangeTaleScene()
    {
        SceneManager.LoadScene("ExtraScene5");
    }
}
