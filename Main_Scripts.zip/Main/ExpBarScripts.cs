﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class ExpBarScripts : MonoBehaviour
{

    public Image ExpBarImg;
    public float MaxExp = 100;
    public float CurExp = 30;

    void Start()
    {
        ExpBarImg.fillAmount = CurExp / MaxExp;
    }

    // Update is called once per frame
    void Update()
    {

    }

}


/*


    
 */
