﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System.Data;

public class StaminaBarScripts : MonoBehaviour {

    public Slider StmBarSlider;  //reference for slider
    public float stamina = 30;
    public float max_stamina = 100;

    void Start()
    {
        StmBarSlider.value = stamina / max_stamina;
    }

    // Update is called once per frame
    void Update()
    {

    }
    /*
    public DataTable selsql(string sqlcmd)  //리턴 형식을 DataTable로 선언함
    {
        DataTable dt = new DataTable(); //데이터 테이블을 선언함

        sqlConnect();
        MySqlDataAdapter adapter = new MySqlDataAdapter(sqlcmd, sqlconn);
        adapter.Fill(dt); //데이터 테이블에  채워넣기를함
        sqldisConnect();

        return dt; //데이터 테이블을 리턴함
    }
    */

}