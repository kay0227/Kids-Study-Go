﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelTextScripts : MonoBehaviour {
    public Text LevelText;
    public int level = 5;

    // Use this for initialization
    void Start () {
        LevelText.text = level.ToString();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
