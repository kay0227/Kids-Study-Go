﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnScripts : MonoBehaviour {
    
    public bool enableSpawn = false;
    public GameObject SpawnObject1; //Prefab을 받을 public 변수 입니다.
    public GameObject SpawnObject2;
    public GameObject SpawnObject3;
    int time = 0;

    /*
    void Start()
    {
        InvokeRepeating("SpawnEnemy", 1, 10); //1초후 부터, SpawnEnemy함수를 10초마다 반복해서 실행 시킵니다.
    }

    void Update()
    {
        
    }

    void SpawnEnemy()
    {
        float randomX = Random.Range(0f, 1f); //적이 나타날 X좌표를 랜덤으로 생성해 줍니다.(20~180)
        float randomY = Random.Range(0f, 1f); //적이 나타날 Y좌표를 랜덤으로 생성해 줍니다.(30~320)

        Vector3 worldPos = Camera.main.ViewportToWorldPoint(new Vector3(randomX, randomY, 0f));
        worldPos.z = 0f;

        if (enableSpawn)
        {
            GameObject enemy = (GameObject)Instantiate(SpawnObject, worldPos, Quaternion.identity); //랜덤한 위치와, 지정된 좌표에서 Enemy를 하나 생성해줍니다.
            //print(worldPos); //test code
            SpawnObject.SetActive(true);
        }
    }
    */

    void Start()
    {
        StartCoroutine(RandomSpawn());
    }
    
    void Update()
    {

    }

    Vector3 Setpos()
    {
        float PosX = Random.Range(-1f, 1f);
        float PosY = Random.Range(-2f, 2f);

        //Vector3 Pos = Camera.main.ViewportToWorldPoint(new Vector3(PosX, PosY, 0));
        Vector3 Pos = new Vector3(PosX, PosY, 0);
        Pos.z = 0;

        return Pos;
    }
    
    IEnumerator RandomSpawn()
    {
        while(true)
        {
            switch(time%3)
            {
                case 0:
                    Instantiate(SpawnObject1, Setpos(), Quaternion.identity);
                    SpawnObject1.SetActive(true);
                    break;
                case 1:
                    Instantiate(SpawnObject2, Setpos(), Quaternion.identity);
                    SpawnObject2.SetActive(true);
                    break;
                case 2:
                    Instantiate(SpawnObject3, Setpos(), Quaternion.identity);
                    SpawnObject3.SetActive(true);
                    break;
            }
            time++;
            yield return new WaitForSeconds(1f);
        }
    }

    /*
    Destroy(this.GameObject) 함수 추가 
     */
}

/*
public bool enableSpawn = false;
        public GameObject Enemy; //Prefab을 받을 public 변수 입니다.
        void SpawnEnemy()
        {
            float randomX = Random.Range(-0.5f, 0.5f); //적이 나타날 X좌표를 랜덤으로 생성해 줍니다.
            if (enableSpawn)
            {
                GameObject enemy = (GameObject)Instantiate(Enemy, new Vector3(randomX, 0.5f, 0f), Quaternion.identity); //랜덤한 위치와, 화면 제일 위에서 Enemy를 하나 생성해줍니다.
            }
        }
        void Start()
        {
            InvokeRepeating("SpawnEnemy", 3, 1); //3초후 부터, SpawnEnemy함수를 1초마다 반복해서 실행 시킵니다.
        }
        void Update()
        {

        }
*/
