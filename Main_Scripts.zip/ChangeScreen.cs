﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
//using System;

public class ChangeScreen : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ChangeGameScene()
    {
        SceneManager.LoadScene("Tltle");
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        //throw new NotImplementedException();
        SceneManager.LoadScene("Title");
        Debug.Log("Mouse Down: " + eventData.pointerCurrentRaycast.gameObject.name);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        //throw new NotImplementedException();
        SceneManager.LoadScene("Title");
        Debug.Log("Mouse Up");
    }
}
